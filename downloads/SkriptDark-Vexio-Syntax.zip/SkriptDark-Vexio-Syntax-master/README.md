### Vexio's Skript Dark Theme for Atom

## Screenshots

![picture 1](http://bryce.hoffho.us/i/icjku28.png)

![picture 2](http://bryce.hoffho.us/i/r8fjkcv.png)

## How to Install

**Step 1**: Open Atom
**Step 2**: Execute the keyboard function *(For Mac)* `command ⌘ + ,` *(For Windows)* `Ctrl + ,` to open the settings
**Step 3**: From the sidebar, select `+ Install`
**Step 4**: Search up `SkriptDark-Vexio-Syntax`
**Step 5**: Select Install
**Step 6**: On the sidebar in Settings, select `Themes`
**Step 7**: Under *Syntax Theme*, select `Skript Dark Vexio Syntax`
